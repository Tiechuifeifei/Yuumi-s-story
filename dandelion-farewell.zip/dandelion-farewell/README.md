# Dandelion Farewell · 蒲公英

A generative, interactive piece made with [p5.js](https://p5js.org/).

**Live:** https://YOUR-USERNAME.github.io/dandelion-farewell/

<!-- Add a short screen recording here, e.g. ![demo](media/demo.gif) -->

## The piece

Three dandelions grow on warm paper: vermilion, grey and indigo. They meet, they dance, and they are tied together by fine threads. Then the wind comes. The grey one comes apart. As it leaves, it carries two seeds away from each of the others and leaves two of its own behind. In the end, only four threads still join vermilion and indigo.

The path is different every time: how they meet, the dance they share, the shape of every seed. The moment of parting never changes. The wind always rises at 11.25 seconds, and the ending is always the same.

## How to view

- The first run is always the original version.
- **Press and hold** the canvas to try to keep them. The flowers draw closer and the threads pull tight. Hold through the wind and the grey one trembles and is pulled back for a moment, but it still leaves at the same moment.
- **换一次 (Another time)** draws a new version: one of three meetings × six dances, with different seeds.
- **重看这一次 (See this one again)** replays the current version.
- Add `#seed-<number>` to the URL to open a specific version.

## How it works

- Every brush stroke is drawn from Bézier curves. Stems and tufts are filled outlines whose width and ink change along the stroke. The paper grain is generated once and reused on every frame.
- Motion is choreographed with easing and pulse functions on a fixed timeline instead of keyframes.
- Each run draws a random seed. It chooses the meeting, the dance and the details of every floret. The times of the wind and of the two departures are fixed constants.
- Holding is recorded as a strength over time. Past moments are always calculated from that record, so letting go never rewrites what has already happened.

## Files

| File | Contents |
| --- | --- |
| `index.html` | Page, controls and labels |
| `sketch.js` | The p5.js sketch |
| `lib/p5.min.js` | p5.js 1.9.4 (LGPL-2.1), included so the page works offline |

To run it locally, download the repository and open `index.html` in a browser.

## Credits

The original piece is my own: its visual language, the drawing code, the story and its timing. The random variations (meetings and dances) the press-and-hold interaction and the web page controls were developed with the help of Claude (Anthropic), building on the original code.
