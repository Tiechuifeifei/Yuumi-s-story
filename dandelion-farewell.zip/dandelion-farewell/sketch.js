new p5(p => {
  const W = 540, H = 960, WIND = 11.25;
  const DEPART = [12.38, 13.29];
  const pink = [177, 73, 63];
  const gray = [101, 108, 124];
  const blue = [48, 97, 155];
  const root = { x: 248, y: 901 };
  const blueRoot = { x: 306, y: 913 };
  const { sin, cos, PI, hypot, sqrt, exp } = Math;

  const point = (x, y) => ({ x, y });
  const add = (a, b) => point(a.x + b.x, a.y + b.y);
  const mix = (a, b, u) => a + (b - a) * u;
  const between = (a, b, u) => point(mix(a.x, b.x, u), mix(a.y, b.y, u));

  function ease(a, b, t) {
    const u = Math.max(0, Math.min(1, (t - a) / (b - a)));
    return u * u * (3 - 2 * u);
  }

  const pulse = (a, b, c, t) => ease(a, b, t) * (1 - ease(b, c, t));
  const color = (r, g, b, a) => 'rgba(' + r + ',' + g + ',' + b + ',' + a / 255 + ')';

  let heads, bundles, context, started, fate;

  // 每次运行抽一个新的种子；离别的时刻（WIND、DEPART）和结局位置始终不变。
  // 网址末尾加 #seed-123 可以固定重现某一个版本。
  const fixedSeed = (() => {
    const m = /^#seed-(\d+)$/.exec(location.hash);
    return m ? Number(m[1]) >>> 0 : null;
  })();
  let currentSeed;

  // 挽留：按住画面的力度（0 到 1），按时间记下来，
  // 让已经发生的过去不会因为现在松手而改变。
  let pressed = false, hold = 0, lastFrame = 0, holdHistory = [];

  function holdAt(t) {
    const n = holdHistory.length;
    if (n === 0 || t <= holdHistory[0][0]) return n ? holdHistory[0][1] : 0;
    if (t >= holdHistory[n - 1][0]) return holdHistory[n - 1][1];
    let lo = 0, hi = n - 1;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (holdHistory[mid][0] <= t) lo = mid; else hi = mid;
    }
    const [t0, h0] = holdHistory[lo], [t1, h1] = holdHistory[hi];
    return mix(h0, h1, (t - t0) / (t1 - t0 || 1));
  }

  function play(value) {
    currentSeed = value;
    hold = 0;
    holdHistory = [];
    compose(value);
    started = p.millis();
    p.loop();
    window.dispatchEvent(new CustomEvent('dandelion-seed', {
      detail: { seed: value, meeting: fate.meeting, dance: fate.dance }
    }));
  }

  window.dandelion = {
    replay: () => play(currentSeed),
    next: () => play(freshSeed()),
    pose: t => pose(t),
    fate: () => fate
  };
  const freshSeed = () => crypto.getRandomValues(new Uint32Array(1))[0];

  // 固定纸纹，每帧沿用同一张底纸。
  const sheet = document.createElement('canvas');
  sheet.width = W;
  sheet.height = H;
  const paper = sheet.getContext('2d');
  const grain = paper.createImageData(W, H);
  let fiber = 1599;

  function fleck() {
    fiber = (Math.imul(fiber, 1664525) + 1013904223) >>> 0;
    return fiber / 4294967296;
  }

  for (let i = 0; i < grain.data.length; i += 4) {
    const n = Math.floor((fleck() + fleck() - 1) * 11);
    grain.data.set([250 + n, 241 + n, 222 + n, 255], i);
  }

  paper.putImageData(grain, 0, 0);
  paper.strokeStyle = 'rgba(143,104,65,0.08)';
  paper.lineWidth = 0.35;
  paper.beginPath();

  for (let i = 0; i < 4100; i++) {
    const x = fleck() * W, y = fleck() * H;
    paper.moveTo(x, y);
    paper.lineTo(x + fleck() * 4 - 2, y + fleck() * 2 - 1);
  }

  paper.stroke();

  let rng;
  let pigment, brushWidth, brushMark = 0, tuftStroke = false;

  function brush(x, y, a, b, c, d, e, f) {
    const stemStroke = brushWidth > 2.6;
    const count = hypot(e - x, f - y) < 38 ? 4 : 9;

    const at = u => {
      const v = 1 - u;
      return [
        v * v * v * x + 3 * v * v * u * a + 3 * v * u * u * c + u * u * u * e,
        v * v * v * y + 3 * v * v * u * b + 3 * v * u * u * d + u * u * u * f
      ];
    };

    const tangent = u => {
      const v = 1 - u;
      return [
        v * v * (a - x) + 2 * v * u * (c - a) + u * u * (e - c),
        v * v * (b - y) + 2 * v * u * (d - b) + u * u * (f - d)
      ];
    };

    // 花梗和绒毛用连续轮廓绘制，粗细与墨色沿笔画过渡。
    if (stemStroke || tuftStroke) {
      const left = [], right = [];
      const samples = stemStroke ? 96 : 12;

      for (let i = 0; i <= samples; i++) {
        const u = i / samples;
        const [px, py] = at(u);
        const [dx, dy] = tangent(u);
        const length = hypot(dx, dy) || 1;
        const pressure = stemStroke
          ? 0.52 + 0.49 * sin(PI * u) + 0.23 * u
          : (1.20 - 1.14 * u ** 0.78) * (1 + 0.08 * sin(brushMark + u * 5));
        const taper = stemStroke
          ? 1 - 0.55 * Math.max(0, (u - 0.975) / 0.025) ** 2
          : 1;
        const radius = 0.5 * brushWidth * pressure * taper;
        const nx = -dy / length * radius;
        const ny = dx / length * radius;
        left.push([px + nx, py + ny]);
        right.push([px - nx, py - ny]);
      }

      const gradient = context.createLinearGradient(x, y, e, f);
      const [red, green, blue, alpha] = pigment;
      gradient.addColorStop(0, color(red, green, blue, alpha * (stemStroke ? 0.87 : 1)));
      gradient.addColorStop(0.47, color(red, green, blue, alpha * (stemStroke ? 0.98 : 0.82)));
      gradient.addColorStop(1, color(red, green, blue, alpha * (stemStroke ? 0.91 : 0.37)));

      context.fillStyle = gradient;
      context.beginPath();
      context.moveTo(...left[0]);
      for (let i = 1; i < left.length; i++) context.lineTo(...left[i]);
      for (let i = right.length - 1; i >= 0; i--) context.lineTo(...right[i]);
      context.closePath();
      context.fill();
      return;
    }

    for (let i = 0; i < count; i++) {
      const u = i / count, v = (i + 1) / count;
      const mid = (u + v) * 0.5;
      const [sx, sy] = at(u), [ex, ey] = at(v);
      const [tx, ty] = tangent(u), [ux, uy] = tangent(v);
      const tooth = 0.84 + 0.16 * sin(i * 2.39 + brushMark);
      const dry = i % 6 === 3;
      const pressure = 1.13 - 0.86 * mid ** 0.9;

      context.lineWidth = brushWidth * pressure * (0.78 + 0.25 * tooth);
      context.strokeStyle = color(
        pigment[0], pigment[1], pigment[2],
        pigment[3] * tooth * (dry ? 0.70 : 1)
      );
      context.beginPath();
      context.moveTo(sx, sy);
      context.bezierCurveTo(
        sx + tx / count, sy + ty / count,
        ex - ux / count, ey - uy / count,
        ex, ey
      );
      context.stroke();
    }
  }

  const pen = {
    randomSeed(v) { rng = v; },
    random(a, b) {
      rng = (Math.imul(rng, 1664525) + 1013904223) >>> 0;
      const u = rng / 4294967296;
      if (a === undefined) return u;
      if (b === undefined) return u * a;
      return a + u * (b - a);
    },
    stroke(...c) { pigment = c; },
    fill(...c) { context.fillStyle = color(...c); },
    strokeWeight(w) { brushWidth = w; },
    bezier: brush,
    brushPhase(mark) { brushMark = mark; },
    tuftBrush(active) { tuftStroke = active; },
    circle(x, y, d) {
      context.beginPath();
      context.arc(x, y, d / 2, 0, 2 * PI);
      context.fill();
    }
  };

  // 相遇的三种方式。
  const MEETINGS = {
    // 灰色主动靠过去
    reach: t => [pulse(2.9, 4.15, 5.8, t), 0],
    // 朱红主动迎上来
    answer: t => [0.25 * pulse(2.9, 4.15, 5.8, t), pulse(3.1, 4.4, 6.0, t)],
    // 灰色靠近、退开、再靠近
    hesitate: t => [0.7 * pulse(2.7, 3.35, 4.05, t) + pulse(4.3, 5.0, 6.1, t), 0]
  };

  // 离别前一起度过的那段时间：六种不同的舞。
  const DANCES = {
    // 绕着同一个中心转圈（原版）
    orbit: (i, b, k) => k.orbit,
    // 并排站着，一起左右摇摆
    row: (i, b) => {
      const slot = fate.order[i], w = ease(7.3, 8.6, b);
      return point(
        270 + (slot - 1) * 112 + 32 * w * sin((b - 7.3) * 1.9 + slot * 0.5),
        388 + 18 * sin((b - 7.3) * 3.8 + slot * 1.3)
      );
    },
    // 挤在一起慢慢呼吸，最后一刻才被分开
    huddle: (i, b) => {
      const r = 30 + 12 * sin((b - 7.6) * 2.4) + 105 * ease(10.4, 11.5, b);
      const a = fate.swayPhase + i * 2.094 + 0.32 * (b - 7.15);
      return point(270 + r * cos(a), 404 + 0.8 * r * sin(a));
    },
    // 沿着 8 字互相追逐
    chase: (i, b) => {
      const th = fate.swayPhase + i * 2.094 + 1.45 * (b - 7.15);
      return point(270 + 138 * sin(th), 398 + 74 * sin(2 * th));
    },
    // 灰色像秋千一样在朱红和蓝之间来回荡
    swing: (i, b) => {
      if (i === 1) {
        const phi = 0.64 * sin((b - 7.3) * 1.75) * ease(7.15, 8.0, b);
        return point(270 + 205 * sin(phi), 225 + 205 * cos(phi));
      }
      const side = i === 0 ? 1 : -1;
      const near = Math.max(0, side * sin((b - 7.3) * 1.75)) ** 3;
      return point(270 + side * (138 - 22 * near), 352 - 26 * near);
    },
    // 一个接一个被托起来，又落下
    rise: (i, b) => {
      const slot = fate.order[i];
      const up = pulse(7.5 + slot * 0.75, 8.5 + slot * 0.75, 10.3 + slot * 0.55, b);
      return point(
        270 + (slot - 1) * 122 + 14 * sin((b - 7.2) * 1.6 + slot),
        430 - 170 * up
      );
    }
  };

  function pose(t, calm = false) {
    const h = holdAt(t);
    // 起风前后按住：灰色被拉住，发抖、往回坠。
    const struggle = calm ? 0 : h * pulse(WIND - 0.9, WIND + 0.4, DEPART[1] + 0.7, t);
    const [lean, answer] = MEETINGS[fate.meeting](t);
    const greet = fate.greet * lean;
    const meet = fate.meet * pulse(5.9, 7.35, 9.1, t);
    const sway = point(
      fate.sway * 8 * sin(t * 0.84 + fate.swayPhase),
      fate.sway * 4 * sin(t * 0.84 - 0.5 + fate.swayPhase)
    );
    const opening = [
      point(158 + 37 * greet + 70 * answer, 383 + 15 * greet + 52 * answer),
      point(268 - 46 * greet + 43 * meet, 463 - 24 * greet - 44 * meet),
      point(397 - 24 * meet, 312 + 16 * meet)
    ].map((c, i) => add(c, fate.open[i]));
    const growth = [1, ease(1.15, 3.65, t), ease(5, 7.25, t)];
    const sizes = [1, ease(2.08, 3.72, t), ease(6.02, 7.41, t)];
    const delays = [0.09, 0, 0.17];
    const angles = [3.08, 1.57, -0.60];
    const ending = [point(392, 356), point(270, 453), point(147, 324)];

    const shapes = opening.map((center, i) => {
      const beat = t - delays[i];
      const join = ease(7.15, 8.15, beat);
      const outward = ease(8.18, 9.42, beat);
      const turn = 2.72 * ease(9.03, 12.15, beat);
      const radius = 49 + 82 * outward
        - 24 * fate.breath * pulse(9.43, 10.21, 10.91, beat)
        + 21 * fate.breath * pulse(10.72, 11.54, 12.42, beat);
      const lift = fate.breath * (-14 * pulse(8.42, 9.18, 9.92, beat)
        - 19 * pulse(10.43, 11.40, 12.28, beat));
      const heading = angles[i] + fate.angle[i] + turn;
      const orbit = point(
        270 + 10 * sin(turn) + radius * cos(heading),
        404 + lift + 0.74 * radius * sin(heading)
      );
      const settle = ease(11.68, i === 1 ? 14.15 : 13.54, beat);
      const path = DANCES[fate.dance](i, beat, { orbit });
      const dance = between(path, ending[i], settle);
      const tugAt = i === 0 ? DEPART[0] : DEPART[1];
      const tug = i === 1 ? 0
        : pulse(tugAt - 0.65, tugAt, tugAt + 0.78, t) * (1 + 1.3 * h);
      const tugOffset = point((i === 0 ? -1 : 1) * 14 * tug, -17 * tug);
      const tremor = i === 1 ? point(
        struggle * (6 * sin(t * 29) + 3.5 * sin(t * 47)),
        struggle * (4 * sin(t * 37) + 10)
      ) : point(0, 0);
      const moved = add(add(add(between(center, dance, join), sway), tugOffset), tremor);

      return {
        moved,
        growth: growth[i],
        size: sizes[i],
        turn: 0.07 * sin(t * 1.32 - i * 0.38) + 0.86 * turn
          + 0.19 * sin(turn) + 0.13 * outward * (1 - settle)
          + fate.spin * sin(1.7 * (beat - 7.15) + i) * join * (1 - settle)
      };
    });

    // 按住时，三朵花互相靠拢。
    if (h > 0.001) {
      const c = shapes.reduce((m, q) => add(m, point(q.moved.x / 3, q.moved.y / 3)), point(0, 0));
      for (const q of shapes) q.moved = between(q.moved, c, 0.17 * h);
    }

    return shapes.map((q, i) => ({
      center: between(i === 2 ? blueRoot : root, q.moved, q.growth),
      size: q.size,
      turn: q.turn
    }));
  }

  function seed(angle, r, size) {
    return {
      angle, r, size,
      phase: pen.random(2 * PI),
      hair: pen.random(11, 29) * size,
      ink: pen.random(0.55, 1),
      bend: pen.random(-14, 14),
      rays: Math.floor(pen.random(4, 8))
    };
  }

  function flower(ink, size, radius, count, phase, gap) {
    const seeds = [];
    const innerCount = Math.round(count * 0.43);
    const rimCount = count - innerCount;

    for (let i = 0; i < count; i++) {
      const inner = i < innerCount;
      const index = inner ? i : i - innerCount;
      const angle = phase + (inner
        ? index * 2.399963
        : (index + 0.5) * 2 * PI / rimCount
      ) + pen.random(-0.055, 0.055);
      const reach = radius * (inner
        ? 0.76 * sqrt((index + 0.7) / innerCount)
        : pen.random(0.88, 1.025)
      );

      const floret = seed(angle, reach, size);
      // 这段外缘先由随后飞走的两颗种子补齐。
      if (!inner && gap !== undefined && cos(angle - gap) > cos(0.30)) continue;
      seeds.push(floret);
    }

    return { ink, seeds };
  }

  const extreme = (seeds, angle) => seeds.reduce((a, b) =>
    a.r * cos(a.angle - angle) > b.r * cos(b.angle - angle) ? a : b
  );

  function silkAnchors(seeds, direction) {
    const facing = seeds.filter(s =>
      s.r > 16 && (s.r < 39 || cos(s.angle - direction) > -0.62)
    );
    return facing.sort((a, b) =>
      a.r * sin(a.angle - direction) - b.r * sin(b.angle - direction)
    );
  }

  p.setup = () => {
    p.pixelDensity(Math.min(window.devicePixelRatio || 1, 2));
    const canvas = p.createCanvas(W, H);
    context = p.drawingContext;
    context.lineCap = 'round';
    context.lineJoin = 'round';

    Object.assign(document.body.style, {
      margin: '0',
      background: '#FAF1DE'
    });
    Object.assign(canvas.elt.style, {
      display: 'block',
      width: 'min(100%, calc((100vh - 64px) * 0.5625))',
      height: 'auto',
      margin: '0 auto',
      touchAction: 'none',
      userSelect: 'none',
      webkitUserSelect: 'none',
      webkitTouchCallout: 'none'
    });

    if (CSS.supports('height', '100dvh')) {
      canvas.elt.style.width = 'min(100%, calc((100dvh - 64px) * 0.5625))';
    }
    const controls = document.getElementById('controls');
    controls.parentNode.insertBefore(canvas.elt, controls);

    // 点击重播时会是另一个版本，但离别仍在同一刻发生。
    // 按住画面＝挽留。
    const press = e => {
      e.preventDefault();
      pressed = true;
      try { canvas.elt.setPointerCapture(e.pointerId); } catch (_) {}
      p.loop();
    };
    const letGo = () => { pressed = false; };
    canvas.elt.addEventListener('pointerdown', press);
    canvas.elt.addEventListener('pointerup', letGo);
    canvas.elt.addEventListener('pointercancel', letGo);
    canvas.elt.addEventListener('lostpointercapture', letGo);
    canvas.elt.addEventListener('contextmenu', e => e.preventDefault());

    // 第一次打开总是原版；之后点“换一次”才抽其他版本。
    play(fixedSeed ?? 'original');
  };

  function pick(list) {
    return list[Math.floor(pen.random(list.length))];
  }

  // 原版的全部参数，配合种子 42，与最初的作品完全一致。
  const ORIGINAL = {
    sway: 1, swayPhase: 0, greet: 1, meet: 1, breath: 1,
    open: [point(0, 0), point(0, 0), point(0, 0)],
    angle: [0, 0, 0], phase: [0, 0, 0], count: [0, 0, 0],
    meeting: 'reach', dance: 'orbit', spin: 0, order: [0, 1, 2]
  };

  function compose(value) {
    if (value === 'original') {
      pen.randomSeed(42);
      fate = ORIGINAL;
      buildHeads();
      return;
    }
    pen.randomSeed(value);

    // 离别之前的一切：相遇的路径、靠近的幅度、舞步的呼吸、每颗种子的样子。
    fate = {
      sway: pen.random(0.6, 1.4),
      swayPhase: pen.random(2 * PI),
      greet: pen.random(0.65, 1.3),
      meet: pen.random(0.65, 1.3),
      breath: pen.random(0.6, 1.4),
      open: [0, 1, 2].map(() => point(pen.random(-22, 22), pen.random(-18, 18))),
      angle: [0, 1, 2].map(() => pen.random(-0.32, 0.32)),
      phase: [0, 1, 2].map(() => pen.random(-0.5, 0.5)),
      count: [0, 1, 2].map(() => Math.round(pen.random(-5, 5))),
      meeting: pick(Object.keys(MEETINGS)),
      dance: pick(Object.keys(DANCES)),
      spin: pen.random(0.15, 0.6),
      order: [0, 1, 2]
    };
    for (let i = 2; i > 0; i--) {
      const j = Math.floor(pen.random(i + 1));
      [fate.order[i], fate.order[j]] = [fate.order[j], fate.order[i]];
    }
    buildHeads();
  }

  function buildHeads() {

    heads = [
      flower(pink, 1, 94, 62 + fate.count[0], 1.3 + fate.phase[0], 0.45),
      flower(gray, 0.70, 61, 36 + fate.count[1], 3.2 + fate.phase[1]),
      flower(blue, 1.08, 106, 66 + fate.count[2], 5.1 + fate.phase[2], 2.55)
    ];

    heads[0].taken = [seed(0.28, 91, 1), seed(0.59, 90, 1)];
    heads[2].taken = [seed(2.39, 102, 1.08), seed(2.71, 103, 1.08)];
    heads[1].kept = [
      [seed(3.12, 46, 0.70), seed(3.63, 52, 0.70)],
      [seed(-0.27, 54, 0.70), seed(0.29, 47, 0.70)]
    ];
    heads[1].hooks = [
      extreme(heads[1].seeds, 2.75),
      extreme(heads[1].seeds, 0.32)
    ];

    for (const s of heads[1].seeds) {
      s.leave = WIND + 2.55 * pen.random() ** 1.55;
      s.wind = point(pen.random(-23, 61), pen.random(-123, -57));
    }

    for (const [i, hook] of heads[1].hooks.entries()) {
      hook.leave = DEPART[i] - 0.58;
      hook.wind = point(i === 0 ? -16 : 21, i === 0 ? -90 : -76);
    }

    const pairs = [
      [0, 1, 25, 3.25, 11.48, 0.45, 3.5],
      [1, 2, 27, 6.53, 11.67, -0.35, 2.72],
      [0, 2, 12, 7.61, 12.18, -0.29, 2.87]
    ];

    bundles = pairs.flatMap(([a, b, n, show, cut, dirA, dirB]) => {
      const left = silkAnchors(heads[a].seeds, dirA);
      const right = silkAnchors(heads[b].seeds, dirB);

      return Array.from({ length: n }, (_, i) => {
        const u = (i + 0.5) / n;
        const v = i % 3 === 0 ? 1 - u : (u + (i % 2 ? 0.26 : 0.06)) % 1;
        return {
          a, b, show,
          cut: cut + pen.random(-0.36, 0.72),
          // 朱红和蓝色之间保留这四缕丝。
          holdsAtEnd: a === 0 && b === 2 && [1, 4, 7, 10].includes(i),
          u: left[Math.floor(u * left.length)],
          v: right[Math.floor(v * right.length)],
          lane: pen.random(-17, 17),
          sag: pen.random(0.52, 1.35),
          phase: pen.random(2 * PI),
          depth: pen.random(0.48, 1),
          ink: heads[i % 2 ? b : a].ink,
          alternate: i % 5 === 2
        };
      });
    });
  }

  function tip(f, s, t) {
    const a = s.angle + f.turn + 0.06 * sin(t * 2.6 + s.phase);
    return add(f.center, point(cos(a) * s.r * f.size, sin(a) * s.r * f.size));
  }

  function bezier(a, b, c, d) {
    pen.bezier(a.x, a.y, b.x, b.y, c.x, c.y, d.x, d.y);
  }

  function stroke(ink, alpha, width) {
    pen.stroke(...ink, alpha);
    pen.strokeWeight(width);
  }

  function drawThread(a, c, d, b, cut = 0) {
    if (cut === 0) {
      bezier(a, c, d, b);
      return;
    }

    // 两截沿原来的曲线各自回缩。
    function retract(start, c1, c2, end) {
      const u = 0.5 * (1 - cut);
      const ab = between(start, c1, u);
      const bc = between(c1, c2, u);
      const cd = between(c2, end, u);
      const left = between(ab, bc, u), right = between(bc, cd, u);
      bezier(start, ab, left, between(left, right, u));
    }

    retract(a, c, d, b);
    retract(b, d, c, a);
  }

  function strand(a, b, bowA, bowB, ink, alpha, width) {
    const dx = b.x - a.x, dy = b.y - a.y;
    const span = hypot(dx, dy);
    if (span < 0.25 || alpha < 0.8) return;

    const normal = point(-dy / span, dx / span);
    const control = (u, v) => add(between(a, b, u), point(normal.x * v, normal.y * v));
    stroke(ink, alpha, width);
    bezier(a, control(0.32, bowA), control(0.70, bowB), b);
  }

  function tuft(at, s, ink, turn, t, size, alpha) {
    if (size < 0.015 || alpha < 0.015) return;

    const heading = s.angle + turn + 0.13 * sin(t * 2 + s.phase);
    const length = s.hair * size;
    const local = (x, y) => add(at, point(
      x * cos(heading) - y * sin(heading),
      x * sin(heading) + y * cos(heading)
    ));
    const rays = s.rays + 4;
    const strongOffset = Math.floor(s.phase * 3) % 3;

    pen.tuftBrush(true);

    for (let i = 0; i < rays; i++) {
      const fan = mix(-1, 1, i / (rays - 1));
      const reach = length * (0.69 + 0.31 * sin(s.phase + i * 1.64) ** 2);
      const flare = Math.abs(fan);
      const side = reach * (1.10 * fan + 0.06 * sin(s.phase + i * 3.2));
      const height = reach * (0.59 + 0.36 * (1 - flare ** 1.45));
      const end = local(height, side);
      const c1 = local(height * 0.19, side * 0.88);
      const c2 = local(height * 0.62, side * 1.04);

      pen.brushPhase(s.phase + i * 1.71);
      const strong = (i + strongOffset) % 3 === 0;
      const weight = (strong ? 1.75 : 0.83) * (0.72 + 0.28 * size)
        * (0.78 + 0.22 * sin(s.phase * 1.9 + i * 2.17) ** 2);
      const density = strong ? 212 : 148;
      stroke(ink, density * alpha * (0.48 + 0.52 * s.ink), weight);
      bezier(at, c1, c2, end);

      if (i % 2 === 0 && reach > 6.5) {
        const sprout = add(at, point(
          0.27 * (c1.x - at.x) + 0.42 * (c2.x - at.x) + 0.22 * (end.x - at.x),
          0.27 * (c1.y - at.y) + 0.42 * (c2.y - at.y) + 0.22 * (end.y - at.y)
        ));
        const fork = local(
          height + reach * 0.08,
          side + reach * (fan < 0 ? -0.15 : 0.15)
        );
        stroke(ink, 87 * s.ink * alpha, 0.44);
        bezier(sprout, between(sprout, end, 0.64), between(end, fork, 0.62), fork);
      }
    }

    pen.tuftBrush(false);
    pen.brushPhase(0);
    pen.fill(...ink, 182 * alpha * (0.70 + 0.30 * s.ink));
    pen.circle(at.x, at.y, 2.25 * s.size * size);
  }

  function stem(base, end, bend, ink, alpha, width) {
    const h = base.y - end.y;
    if (alpha < 1 || h < 1) return;

    stroke(ink, alpha, width);
    bezier(
      base,
      add(base, point(bend * 0.52, -h * 0.53)),
      add(end, point(bend, h * 0.29)),
      end
    );
  }

  function flyingSeedBody(at, s, ink, turn, age, size, alpha) {
    const visible = ease(0, 0.23, age) * alpha;
    if (visible < 0.015) return;

    const radial = s.angle + turn;
    const hang = ease(0.02, 0.59, age);
    const length = (20 + 5 * sin(s.phase)) * s.size * size;
    const dx = mix(-cos(radial), 0.24 * sin(age * 2.6 + s.phase), hang);
    const dy = mix(-sin(radial), 0.97, hang);
    const foot = add(at, point(dx * length, dy * length));

    strand(at, foot, 1.5 * size, -0.6 * size, ink, 207 * visible, 1.17);

    context.save();
    context.translate(foot.x, foot.y);
    context.rotate(Math.atan2(dy, dx) - PI / 2);
    context.fillStyle = color(...ink, 208 * visible);
    context.beginPath();
    context.ellipse(0, 1.5 * size, 1.45 * s.size * size, 3.25 * s.size * size, 0, 0, 2 * PI);
    context.fill();
    context.restore();
  }

  function receptacle(shape, ink, alpha) {
    if (alpha < 0.015) return;

    const { x, y } = shape.center;
    context.save();
    context.translate(x, y);
    context.scale(shape.size, shape.size);
    context.fillStyle = color(...ink, 170 * alpha);
    context.beginPath();
    context.moveTo(-8.8, 0.6);
    context.bezierCurveTo(-8, -4.9, -4.7, -6.3, 0, -6.1);
    context.bezierCurveTo(4.6, -6.3, 8.1, -4.9, 8.8, 0.6);
    context.bezierCurveTo(5.3, 3.8, -5.3, 3.8, -8.8, 0.6);
    context.closePath();
    context.fill();

    context.fillStyle = color(250, 241, 222, 166 * alpha);
    for (const [px, py] of [
      [-5, -1], [-3, 0.6], [-2, -3], [0, 0.1], [1, -4], [3, -2], [5, -0.1]
    ]) {
      context.beginPath();
      context.ellipse(px, py, 0.57, 0.41, 0, 0, 2 * PI);
      context.fill();
    }
    context.restore();
  }

  function grayFlight(s, t, current) {
    if (t <= s.leave) return tip(current, s, t);

    const age = t - s.leave;
    const start = pose(s.leave)[1];
    const origin = tip(start, s, s.leave);
    const calm = tip(pose(s.leave, true)[1], s, s.leave);
    const earlier = tip(pose(s.leave - 0.01, true)[1], s, s.leave - 0.01);
    const inertia = (1 - exp(-3 * age)) / 0.03;
    const wind = age - (1 - exp(-2 * age)) / 2;
    // 刚离开的种子会被按住的手往回拽一下，但终究还是飞走。
    const held = 1 - 0.55 * holdAt(t) * exp(-age / 0.9);

    return add(origin, point(
      held * ((calm.x - earlier.x) * inertia + s.wind.x * wind
        + 10 * sin(age * 2.2 + s.phase) * ease(0, 1, age)),
      held * ((calm.y - earlier.y) * inertia + s.wind.y * wind - 7 * wind * wind)
    ));
  }

  function drawGray(s, shape, t) {
    const age = Math.max(0, t - s.leave);
    const at = grayFlight(s, t, shape);
    const highlight = heads[1].hooks.includes(s);
    const lull = pulse(11.95, 13.12, 15.85, t);
    const fade = (1 - ease(3.6, 5.5, age))
      * (highlight ? 1 : 1 - 0.51 * lull * ease(0.25, 0.9, age));
    const turn = age > 0 ? pose(s.leave)[1].turn + 0.62 * age : shape.turn;
    const loose = ease(0, 0.36, age);

    strand(
      shape.center, between(at, shape.center, loose * 0.32),
      s.bend, -s.bend * 0.4, gray,
      mix(101, 161, s.ink) * shape.size * (1 - loose),
      mix(0.72, 1.48, s.ink)
    );
    flyingSeedBody(at, s, gray, turn, age, shape.size, shape.size * fade);
    tuft(at, s, gray, turn, t, shape.size, shape.size * fade);
  }

  function drawBundles(f, t) {
    for (const s of bundles) {
      const visible = ease(s.show, s.show + 0.82, t);
      const cut = s.holdsAtEnd ? 0 : ease(s.cut, s.cut + 0.58, t);
      if (visible === 0 || cut === 1) continue;

      const a = s.a === 1 ? grayFlight(s.u, t, f[1]) : tip(f[s.a], s.u, t);
      const b = s.b === 1 ? grayFlight(s.v, t, f[1]) : tip(f[s.b], s.v, t);
      const span = hypot(a.x - b.x, a.y - b.y);
      if (span < 1) continue;

      const left = f[s.a].center, right = f[s.b].center;
      const distance = hypot(left.x - right.x, left.y - right.y);
      const slack = 1 - ease(78, 182, distance);
      const rest = s.holdsAtEnd ? ease(13.2, 16.2, t) : 0;
      const tight = holdAt(t);
      const fall = Math.min(60, 0.37 * span) * (slack * s.sag + 0.53 * rest) * (1 - 0.75 * tight);
      const drift = sin(t * 1.38 + s.phase) * (2 + 7 * slack);
      const alpha = visible * (1 - cut) * s.depth;
      const isPinkBlue = s.a === 0 && s.b === 2;
      const light = isPinkBlue ? (s.alternate ? 165 : 133) : (s.alternate ? 140 : 105);
      const colorPresence = s.holdsAtEnd ? mix(light * s.depth, 108, rest) : light * s.depth;
      const c = add(between(a, b, 0.22),
        point(drift + s.lane * 0.23, fall * 1.20 + s.lane));
      const d = add(between(a, b, 0.68),
        point(drift * 0.63 - s.lane * 0.31, fall + 0.35 * s.lane));

      if (s.alternate) {
        const attachedA = s.a === 1 ? 1 - ease(s.u.leave, s.u.leave + 0.36, t) : 1;
        const attachedB = s.b === 1 ? 1 - ease(s.v.leave, s.v.leave + 0.36, t) : 1;
        strand(left, a, 3, -2, s.ink, 64 * alpha * attachedA, 0.43);
        strand(b, right, -3, 2, s.ink, 64 * alpha * attachedB, 0.43);
      }

      pen.brushPhase(s.phase);
      stroke(s.ink, Math.min(240, colorPresence * (1 + 0.55 * tight)) * visible * (1 - cut),
        (s.alternate ? 1.12 : 0.66) + 0.35 * tight);
      drawThread(a, c, d, b, cut);
    }

    pen.brushPhase(0);
  }

  function exchange(f, t) {
    for (const [side, depart] of DEPART.entries()) {
      const index = side * 2;
      const home = f[index], g = f[1], flower = heads[index];
      const hookSeed = heads[1].hooks[side];
      const hook = grayFlight(hookSeed, t, g);
      const fade = 1 - ease(3.75, 5.5, t - hookSeed.leave);
      const direction = side === 0 ? 1 : -1;

      // 朱红和蓝色的种子先被牵紧，再随灰色的小伞飞走。
      for (const [i, s] of flower.taken.entries()) {
        const release = depart + i * 0.20;
        const grip = ease(release - 0.88, release - 0.42, t);
        const stretch = ease(release - 0.60, release, t);
        const age = Math.max(0, t - release);
        let at = between(tip(home, s, t), hook, 0.30 * stretch);
        let turn = home.turn;

        if (age > 0) {
          const previous = pose(release);
          const a = tip(previous[index], s, release);
          const b = grayFlight(hookSeed, release, previous[1]);
          const relative = point((a.x - b.x) * 0.7, (a.y - b.y) * 0.7);
          const tail = point(direction * (34 + 20 * i), 23 + 22 * i);
          const swing = sin(PI * ease(0, 1.25, age)) * (i === 0 ? 11 : 15);
          at = add(hook, add(
            between(relative, tail, ease(0, 1.03, age)),
            point(direction * swing, 0.8 * swing)
          ));
          turn = previous[index].turn + 0.63 * age;
        }

        const cut = ease(0, 0.18, age);
        strand(home.center, between(at, home.center, 0.44 * cut),
          s.bend * (1 - stretch), -2, flower.ink, 143 * home.size * (1 - cut), 0.68);

        const tension = pulse(release - 0.47, release, release + 0.65, t);
        const slack = 1 - tension;
        const inkWeight = 0.72 + 0.52 * tension;
        strand(at, hook, 12 * slack, -6 * slack, flower.ink,
          (157 + 65 * tension) * grip * home.size * fade, inkWeight);

        const readableSize = home.size
          * (1 + 0.11 * ease(0, 0.52, age) * (1 - ease(1.8, 3.0, age)));
        flyingSeedBody(at, s, flower.ink, turn, age, readableSize, home.size * fade);
        tuft(at, s, flower.ink, turn, t, readableSize, home.size * fade);
      }

      // 两朵花各自接住两颗灰色绒毛。
      for (const [i, s] of heads[1].kept[side].entries()) {
        const start = depart - 0.54 + i * 0.14;
        const catchSilk = ease(start - 0.31, start + 0.05, t);
        const travel = ease(start + 0.05, start + 1.11, t);
        const received = {
          ...s,
          angle: side === 0 ? 0.12 + i * 0.60 : 2.23 + i * 0.59,
          r: 64 + i * 16 + side * 8
        };
        const at = add(
          between(tip(g, s, t), tip(home, received, t), travel),
          point(0, -16 * sin(PI * travel))
        );
        const cut = ease(0.51, 0.83, travel);

        strand(home.center, at, 10, -6, gray, 166 * catchSilk * home.size, 0.73);
        strand(g.center, between(at, g.center, 0.44 * cut),
          -6, 8, gray, 126 * g.size * (1 - cut), 0.68);

        const turn = mix(g.turn, home.turn + received.angle - s.angle, travel);
        const size = mix(g.size, home.size, travel);
        tuft(at, s, gray, turn, t, size, size);
      }
    }
  }

  p.draw = () => {
    const now = p.millis();
    const dt = Math.min(0.1, Math.max(0, (now - lastFrame) / 1000));
    lastFrame = now;
    const t = Math.min(20, (now - started) / 1000);
    hold += ((pressed ? 1 : 0) - hold) * (1 - exp(-(pressed ? 2.6 : 1.5) * dt));
    if (hold < 0.002 && !pressed) hold = 0;
    const last = holdHistory[holdHistory.length - 1];
    if (!last || t > last[0]) holdHistory.push([t, hold]);
    else last[1] = hold;
    const f = pose(t);
    const a = f[0].center, g = f[1].center, b = f[2].center;

    context.drawImage(sheet, 0, 0);
    stem(root, a, -36 + (a.x - 165) * 0.65, pink, 217, 4.15);
    stem(root, g, 11 + (g.x - 252) * 0.61,
      gray, 193 * ease(1.15, 1.7, t), 3.15);
    stem(blueRoot, b, 28 + (b.x - 396) * 0.67,
      blue, 221 * ease(5, 5.65, t), 4.58);

    receptacle(f[0], pink, 0.65);
    receptacle(f[1], gray, ease(1.7, 2.9, t));
    receptacle(f[2], blue, 0.69 * ease(5.65, 6.7, t));
    drawBundles(f, t);

    for (const [i, flower] of heads.entries()) {
      const shape = f[i], alpha = shape.size;
      if (alpha < 0.015) continue;

      for (const s of flower.seeds) {
        if (i === 1) {
          drawGray(s, shape, t);
          continue;
        }

        const at = tip(shape, s, t);
        strand(shape.center, at, s.bend * shape.size, -s.bend * 0.4,
          flower.ink, mix(113, 185, s.ink) * alpha, mix(0.69, 1.83, s.ink));
        tuft(at, s, flower.ink, shape.turn, t, shape.size, alpha);
      }
    }

    exchange(f, t);
    if (t >= 20 && !pressed && hold === 0) p.noLoop();
  };
});